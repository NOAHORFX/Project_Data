from PIL import Image
from flask import Blueprint, render_template, request, jsonify

from static.DLFile.diffModel.model import MY_MODEL as DiffModel
from static.methods.imageProcess import *
from static.methods.videoProcess import *
import matplotlib.pyplot as plt
from io import BytesIO
import base64


bp = Blueprint("functionsPage", __name__, url_prefix="/functions")
UPLOAD_FOLDER = 'static/DLFile/upload_folder'
OUTPUT_FOLDER = 'static/DLFile/output_folder'
OUTPUT_FOLDER_FOR_VIDEO = 'static/DLFile/videoPic/outputFrames'

# model = MY_MODEL(384, 384, 11)
# model.load_weights('static/DLFile/new_weight.h5')

model = None


def load_model(model_path, class_num):
    global model
    model = DiffModel(384, 384, class_num)
    model.load_weights(model_path)
    return model


@bp.route('/imageSeg')
def imageSegmentation():
    load_model('static/DLFile/diffModel/new_weight.h5', 11)
    return render_template("imageSegPage.html")


@bp.route('/startSeg', methods=['POST'])
def startSegment():
    file = request.files['file']
    image = Image.open(file.stream)

    upload_path = os.path.join(UPLOAD_FOLDER)
    if not os.path.exists(upload_path):
        os.makedirs(upload_path)

    filepath = os.path.join(upload_path, file.filename)
    image.save(filepath)

    img, mask = load_image(filepath, mask_path="static/testData/label/" + file.filename.replace('_leftImg8bit.png', '_gtFine_labelTrainIds.png'))

    pred_mask = model.predict(img)
    pred_mask = tf.argmax(pred_mask, axis=-1)
    pred_mask = pred_mask[..., tf.newaxis]
    pred_mask = tf.squeeze(pred_mask, axis=0)
    img = tf.squeeze(img, axis=0)

    overlay_mask = tf.keras.preprocessing.image.array_to_img(pred_mask)
    overlay_image = tf.keras.preprocessing.image.array_to_img(img)
    fig, ax = plt.subplots()
    ax.imshow(overlay_image, alpha=0.3)
    ax.imshow(overlay_mask, alpha=0.7)
    ax.axis('off')

    result_path = os.path.join(OUTPUT_FOLDER, "output" + file.filename)
    plt.savefig(result_path, bbox_inches='tight', pad_inches=0)
    plt.close()

    fig, axes = plt.subplots(1, 2, figsize=(12, 6))
    axes[0].imshow(tf.squeeze(mask, axis=-1), cmap='viridis')
    axes[0].set_title('True Mask')
    axes[0].axis('off')

    axes[1].imshow(pred_mask, cmap='viridis')
    axes[1].set_title('Predicted Mask')
    axes[1].axis('off')

    result_for_compare = os.path.join(OUTPUT_FOLDER, "compare" + file.filename)
    plt.savefig(result_for_compare)

    return jsonify({'message': 'File uploaded and processed', 'result_path': result_path, 'result_for_compare': result_for_compare})


@bp.route('/videoSeg')
def videoSegmentation():
    load_model('static/DLFile/diffModel/new_weight.h5', 11)
    return render_template("videoSegPage.html")


@bp.route('/startVideoSeg', methods=['POST'])
def startVideoSeg():
    file = request.files['file']
    upload_path = os.path.join(UPLOAD_FOLDER)
    if not os.path.exists(upload_path):
        os.makedirs(upload_path)

    filepath = os.path.join(upload_path, file.filename)
    file.save(filepath)

    video_to_frames(filepath)

    frames = [os.path.join('static/DLFile/videoPic/uploadFrames', f) for f in os.listdir('static/DLFile/videoPic/uploadFrames') if f.endswith('.png')]

    for frame_path in frames:
        img = load_image_without_mask(frame_path)

        pred_mask = model.predict(img)
        pred_mask = tf.argmax(pred_mask, axis=-1)
        pred_mask = pred_mask[..., tf.newaxis]
        pred_mask = tf.squeeze(pred_mask, axis=0)
        img = tf.squeeze(img, axis=0)

        overlay_mask = tf.keras.preprocessing.image.array_to_img(pred_mask)
        overlay_image = tf.keras.preprocessing.image.array_to_img(img)

        fig, ax = plt.subplots()
        ax.imshow(overlay_image, alpha=0.5)
        ax.imshow(overlay_mask, alpha=0.5)
        ax.axis('off')

        filename = os.path.basename(frame_path)
        result_path = os.path.join(OUTPUT_FOLDER_FOR_VIDEO, "output_" + filename)
        plt.savefig(result_path, bbox_inches='tight', pad_inches=0)
        plt.close()
    video_path = frames_to_video('static/DLFile/videoPic/outputFrames')

    return jsonify({'message': 'File uploaded and processed', 'video_path': video_path})


@bp.route('/realTimeSeg')
def realTimeSegmentation():
    # tf.keras.backend.clear_session()
    load_model('static/DLFile/new_weight1.h5', 22)
    return render_template("realTimeSegPage.html")


@bp.route('/processEachImg', methods=['POST'])
def processEachImg():
    image_stream = BytesIO(request.data)
    image_stream.seek(0)

    img = load_image_without_path(image_stream)

    pred_mask = model.predict(img)
    pred_mask = tf.argmax(pred_mask, axis=-1)
    pred_mask = pred_mask[..., tf.newaxis]
    pred_mask = tf.squeeze(pred_mask, axis=0)
    img = tf.squeeze(img, axis=0)

    overlay_mask = tf.keras.preprocessing.image.array_to_img(pred_mask)
    overlay_image = tf.keras.preprocessing.image.array_to_img(img)

    fig, ax = plt.subplots()
    ax.imshow(overlay_image, alpha=0.5)
    ax.imshow(overlay_mask, alpha=0.5)
    ax.axis('off')

    # Save the plot to a BytesIO object
    buffer = BytesIO()
    plt.savefig(buffer, format='jpg', bbox_inches='tight', pad_inches=0)
    buffer.seek(0)
    img_str = base64.b64encode(buffer.getvalue()).decode('utf-8')

    plt.close()

    return jsonify({'processedImageData': img_str})


@bp.route('/otherSceneSeg')
def otherSceneSeg():
    load_model('static/DLFile/new_weight1.h5', 22)
    return render_template("otherSceneSeg.html")


@bp.route('/startOtherSceneSeg', methods=['POST'])
def startOtherSceneSeg():
    file = request.files['file']
    image = Image.open(file.stream)

    upload_path = os.path.join(UPLOAD_FOLDER)
    if not os.path.exists(upload_path):
        os.makedirs(upload_path)

    filepath = os.path.join(upload_path, file.filename)
    image.save(filepath)

    img, mask = load_image_for_other_scene(filepath, mask_path="static/testData/otherSceneLabel/" + file.filename.replace('.jpg', '.png'))

    pred_mask = model.predict(img)
    pred_mask = tf.argmax(pred_mask, axis=-1)
    pred_mask = pred_mask[..., tf.newaxis]
    pred_mask = tf.squeeze(pred_mask, axis=0)
    img = tf.squeeze(img, axis=0)

    overlay_mask = tf.keras.preprocessing.image.array_to_img(pred_mask)
    overlay_image = tf.keras.preprocessing.image.array_to_img(img)
    fig, ax = plt.subplots()
    ax.imshow(overlay_image, alpha=0.3)
    ax.imshow(overlay_mask, alpha=0.7)
    ax.axis('off')

    result_path = os.path.join(OUTPUT_FOLDER, "output" + file.filename)
    plt.savefig(result_path, bbox_inches='tight', pad_inches=0)
    plt.close()

    fig, axes = plt.subplots(1, 2, figsize=(12, 6))
    axes[0].imshow(tf.squeeze(mask, axis=-1), cmap='viridis')
    axes[0].set_title('True Mask')
    axes[0].axis('off')

    axes[1].imshow(pred_mask, cmap='viridis')
    axes[1].set_title('Predicted Mask')
    axes[1].axis('off')

    result_for_compare = os.path.join(OUTPUT_FOLDER, "compare" + file.filename)
    plt.savefig(result_for_compare)

    return jsonify({'message': 'File uploaded and processed', 'result_path': result_path, 'result_for_compare': result_for_compare})